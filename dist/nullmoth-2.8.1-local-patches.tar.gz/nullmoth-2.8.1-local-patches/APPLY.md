# NullMoth 2.8.1 local patches

`local-patches.diff` is every source change on top of upstream NullMoth **v2.8.1** (tag `v2.8.1`, commit `41a6494`).
`CHANGED-FILES.txt` lists the changed files (M = modified, A = added). No upstream file is deleted.

## Apply

```bash
git clone --branch v2.8.1 https://github.com/nullmoth/nvidia-macos-driver
cd nvidia-macos-driver
git apply --check /path/to/local-patches.diff && git apply /path/to/local-patches.diff
```

## Rebuild

- Metal plugin: `RELEASE=1 bash build/build_plugin.sh <out-dir>` (needs Xcode + Vulkan-Headers).
- NVK: `bash build/build263.sh` (Mesa 17ca6174, minimum macOS 15.5, AUTO binding only for the qualified raw artifact).
- Codec dylibs (prebuilt upstream binaries): `python3 tools/nvcodec_devnull_fix.py <bundle>/Contents/MacOS/lib{nvdec,nvenc}_*.dylib`, then re-sign the bundle. Required for Chrome hardware decode.
- Kexts: the package includes rebuilt NVAccel variants for macOS 15 and 26, with the CPU-copy counter and PR #467 (default off). Build with `OGKM=/path/to/open-gpu-kernel-modules-620.70.06 bash build/accel_build_all.sh "$PWD/kexts/NVRM" <out-dir>` and the kernel SDK/header setup described by that script.

## Verify

Run each `tools/test_*.py` separately (92 scripts at this checkpoint), not `python3 tools/test_*.py` (which runs only the first one). `test_gl_translation.py` requires the translator dylib argument; `test_resource_phi_fold.py` requires `--deps /path/to/Cargo/deps`; historical negative controls require the upstream git history. Missing history/dependencies are UNKNOWN, not passes. Also run `bash tools/metal_selftest.sh`.

Chrome software A/V measurement: `python3 tools/bench_chrome_av_sync.py /path/to/synchronized-av.mp4 --transitions --out /tmp/av-report`. Its timestamps do not measure physical lip-sync; VP9/AV1/WebRTC/DRM are outside the H.264/HEVC test.

The prebuilt, installable package is `nullmoth-nvidia-2.8.1-local-patched.tar.gz` (see `INSTALL-LOCAL-PATCHED.md`).
